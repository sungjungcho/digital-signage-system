'use client';

import { useState, useEffect, useRef } from 'react';
import YoutubePlayer from './YoutubePlayer';

interface MixedElement {
  type: 'text' | 'image' | 'video' | 'youtube';
  order: number;
  duration: number;
  text?: string;
  fontSize?: string;
  fontColor?: string;
  backgroundColor?: string;
  url?: string;
  autoplay?: boolean;
  loop?: boolean;
  muted?: boolean;
}

interface MixedContentDisplayProps {
  elements: MixedElement[];
}

export default function MixedContentDisplay({ elements }: MixedContentDisplayProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [sortedElements, setSortedElements] = useState<MixedElement[]>([]);
  const [isReady, setIsReady] = useState(false);
  const preloadedImages = useRef<{ [key: string]: HTMLImageElement }>({});
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    // elements가 배열인지 확인
    if (!elements || !Array.isArray(elements)) {
      console.error('MixedContentDisplay: elements is not an array', elements);
      setSortedElements([]);
      return;
    }

    // order 기준으로 정렬
    const sorted = [...elements].sort((a, b) => a.order - b.order);
    setSortedElements(sorted);
    setCurrentIndex(0); // 요소가 변경되면 인덱스 초기화
    setIsReady(false); // 새 elements면 다시 로딩
  }, [elements]);

  // 이미지와 비디오 미리 로드 (확실한 로딩 보장)
  useEffect(() => {
    if (sortedElements.length === 0) return;

    let mounted = true;

    const loadMedia = async () => {
      console.log('[MixedContent] 미디어 로딩 시작:', sortedElements.length, '개');

      try {
        // 모든 이미지를 순차적으로 로드
        for (const element of sortedElements) {
          if (!mounted || !isMountedRef.current) break;

          if (element.type === 'image' && element.url) {
            // 이미 로드된 이미지가 있으면 재사용
            if (preloadedImages.current[element.url]) {
              console.log('[MixedContent] 캐시된 이미지 사용:', element.url);
              continue;
            }

            // 새 이미지 로드
            await new Promise<void>((resolve) => {
              const img = new Image();

              img.onload = () => {
                if (mounted && isMountedRef.current && element.url) {
                  preloadedImages.current[element.url] = img;
                  console.log('[MixedContent] 이미지 로드 완료:', element.url);
                }
                resolve();
              };

              img.onerror = (error) => {
                console.error('[MixedContent] 이미지 로드 실패:', element.url, error);
                resolve(); // 에러가 나도 계속 진행
              };

              // 타임아웃 설정 (10초)
              setTimeout(() => {
                console.warn('[MixedContent] 이미지 로드 타임아웃:', element.url);
                resolve();
              }, 10000);

              if (element.url) {
                img.src = element.url;
              } else {
                resolve();
              }
            });
          }
        }

        if (mounted && isMountedRef.current) {
          console.log('[MixedContent] 모든 미디어 로드 완료');
          setIsReady(true);
        }
      } catch (error) {
        console.error('[MixedContent] 미디어 로딩 오류:', error);
        if (mounted && isMountedRef.current) {
          setIsReady(true); // 에러가 나도 일단 표시
        }
      }
    };

    loadMedia();

    return () => {
      mounted = false;
    };
  }, [sortedElements]);

  useEffect(() => {
    if (sortedElements.length === 0) return;

    const currentElement = sortedElements[currentIndex];

    // 동영상 길이만큼 재생하는 경우 (duration === 0)
    if (currentElement.type === 'video' && currentElement.duration === 0) {
      // 동영상 재생 완료 이벤트를 감지해야 하므로 타이머 사용 안 함
      return;
    }

    // 타이머 설정
    const timer = setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % sortedElements.length);
    }, currentElement.duration);

    return () => clearTimeout(timer);
  }, [currentIndex, sortedElements]);

  if (sortedElements.length === 0) {
    return <div className="w-full h-full flex items-center justify-center bg-black">
      <p className="text-white text-xl">콘텐츠가 없습니다.</p>
    </div>;
  }

  // 미디어 로딩 중
  if (!isReady) {
    return <div className="w-full h-full flex items-center justify-center bg-black">
      <p className="text-white text-xl">로딩 중...</p>
    </div>;
  }

  const currentElement = sortedElements[currentIndex];

  const handleVideoEnd = () => {
    // 동영상 재생 완료 시 다음 콘텐츠로 이동
    setCurrentIndex((prev) => (prev + 1) % sortedElements.length);
  };

  // 안전 체크: currentElement가 유효한지 확인
  if (!currentElement) {
    console.error('유효하지 않은 currentElement:', currentIndex, sortedElements);
    return <div className="w-full h-full flex items-center justify-center bg-black">
      <p className="text-white text-xl">콘텐츠 오류</p>
    </div>;
  }

  // 렌더링
  try {
    return renderElement(currentElement, currentIndex, handleVideoEnd);
  } catch (error) {
    console.error('콘텐츠 렌더링 오류:', error);
    // 에러 발생 시 다음 콘텐츠로 자동 이동
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % sortedElements.length);
    }, 100);
    return <div className="w-full h-full flex items-center justify-center bg-black" />;
  }
}

function renderElement(
  currentElement: MixedElement,
  currentIndex: number,
  handleVideoEnd: () => void
) {
  switch (currentElement.type) {
    case 'text':
      return (
        <div
          key={`text-${currentIndex}`}
          className="w-full h-full flex items-center justify-center"
          style={{
            backgroundColor: currentElement.backgroundColor || '#000000',
            willChange: 'contents'
          }}
        >
          <div
            className="text-center px-8"
            style={{
              color: currentElement.fontColor || '#ffffff',
              fontSize: currentElement.fontSize || '2rem',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word'
            }}
          >
            {currentElement.text}
          </div>
        </div>
      );

    case 'image':
      return (
        <div className="w-full h-full relative bg-black flex items-center justify-center">
          <img
            key={currentElement.url} // URL을 key로 사용해서 React가 재사용하지 않도록
            src={currentElement.url}
            alt="Mixed content image"
            className="w-full h-full object-contain"
            style={{
              display: 'block',
              maxWidth: '100%',
              maxHeight: '100%'
            }}
            loading="eager"
          />
        </div>
      );

    case 'video':
      return (
        <div className="w-full h-full relative">
          <video
            key={currentIndex} // 리렌더링을 위한 key
            src={currentElement.url}
            autoPlay
            muted={currentElement.muted !== false}
            className="w-full h-full object-contain"
            onEnded={currentElement.duration === 0 ? handleVideoEnd : undefined}
          />
        </div>
      );

    case 'youtube':
      if (!currentElement.url) return null;

      // YouTube URL에서 비디오 ID 추출
      let videoId = '';
      try {
        if (currentElement.url.includes('youtube.com/watch?v=')) {
          videoId = new URL(currentElement.url).searchParams.get('v') || '';
        } else if (currentElement.url.includes('youtu.be/')) {
          videoId = currentElement.url.split('youtu.be/')[1]?.split('?')[0] || '';
        } else if (currentElement.url.includes('youtube.com/embed/')) {
          videoId = currentElement.url.split('youtube.com/embed/')[1]?.split('?')[0] || '';
        }
      } catch (error) {
        console.error('YouTube URL 파싱 오류:', error);
      }

      if (!videoId) {
        return <div className="w-full h-full flex items-center justify-center">
          <p className="text-red-500">유효하지 않은 YouTube URL</p>
        </div>;
      }

      return (
        <div className="w-full h-full relative">
          <YoutubePlayer
            key={currentIndex}
            videoId={videoId}
            type="video"
            autoplay={currentElement.autoplay !== false}
            loop={currentElement.loop || false}
            mute={currentElement.muted !== false}
          />
        </div>
      );

    default:
      return null;
  }
}
